import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-page',
  templateUrl: './feedback-page.component.html',
  styleUrls: ['./feedback-page.component.css']
})
export class FeedbackPageComponent implements OnInit {
  msg:string='';

  constructor() { }

  ngOnInit(): void {
  }
  res(){
    this.msg='thank you for your feed back';
    

  }

}
